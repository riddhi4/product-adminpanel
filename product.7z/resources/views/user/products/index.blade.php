@extends('layouts.app')

@section('content')
<div class="container">
    <a href="{{ route('user.enduser.logout') }}">logout</a>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Product</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <div class="container-fluid">
                        <div class="row">
                            @foreach($products as $key => $product)
                                <div class="col-md-3 mb-2">
                                   
                                    @if($product->photo)
                                    <a href="{{ $product->photo->getUrl() }}" target="_blank" style="display: inline-block">
                                        <img src="{{ $product->photo->getUrl('thumb') }}" class="img-thumbnail" width="150px">
                                    </a>
                                @endif
                                <br>
                                    <a href="">{{ $product->name ?? '' }}</a>
                                    <br>
                                    <a href="">{{ $product->price ?? '' }}</a>
                                    <br>
                                    
                                    <a class="btn btn-xs btn-primary" href="{{ route('user.products.show', $product->id) }}">
                                        {{ trans('global.view') }}
                                    </a>
                                
                                </div>
                           
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection