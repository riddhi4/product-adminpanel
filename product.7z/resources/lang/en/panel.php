<?php

return [
    'site_title' => 'Product Management',
];
