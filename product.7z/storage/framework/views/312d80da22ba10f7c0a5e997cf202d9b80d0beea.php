

<?php $__env->startSection('content'); ?>
<div class="container">
    <a href="<?php echo e(route('user.enduser.logout')); ?>">logout</a>
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">
                <div class="card-header">Product</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="container-fluid">
                        <div class="row">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 mb-2">
                                   
                                    <?php if($product->photo): ?>
                                    <a href="<?php echo e($product->photo->getUrl()); ?>" target="_blank" style="display: inline-block">
                                        <img src="<?php echo e($product->photo->getUrl('thumb')); ?>" class="img-thumbnail" width="150px">
                                    </a>
                                <?php endif; ?>
                                <br>
                                    <a href=""><?php echo e($product->name ?? ''); ?></a>
                                    <br>
                                    <a href=""><?php echo e($product->price ?? ''); ?></a>
                                    <br>
                                    
                                    <a class="btn btn-xs btn-primary" href="<?php echo e(route('user.products.show', $product->id)); ?>">
                                        <?php echo e(trans('global.view')); ?>

                                    </a>
                                
                                </div>
                           
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\free demo\product\resources\views/user/products/index.blade.php ENDPATH**/ ?>