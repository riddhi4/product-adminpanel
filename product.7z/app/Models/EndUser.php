<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EndUser extends Model
{
    
    protected $table = 'end_users';
    
   
    public $primaryKey = 'id';
    
   
    public $timestamps = true;
   
    protected $fillable = array('name', 'email', 'password');
   
    protected $guarded = array();
    
    
    protected $hidden = array('password');
}