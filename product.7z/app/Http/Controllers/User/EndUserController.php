<?php

namespace App\Http\Controllers\User;
use App\Models\EndUser;
use Session;
use Auth;
use App\Http\Controllers\Controller;
use Gate;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

use AuthenticatesUsers;

class EndUserController extends Controller
{	
   

    public function index()
    {
		$user = '';

        return view('user.enduser.index');
    }

    
    public function register()
    {
        return view('user.enduser.register');
    }
        
    
    public function registerstore(Request $request)
    {
        
		return EndUser::create([
            'name'     => $request['name'],
            'email'    => $request['email'],
            'password' => ($request['password']),
        ]);
		return view('user.enduser.login');
    }
    
   
    public function login()
    {
        return view('user.enduser.login');
    }
	
	
    public function authenticate(Request $request)
    {		
		if (EndUser::find(array('email' => $request->email, 'password' => $request->password))) {
			return redirect()->route('user.enduser.index');
		} else {
			return redirect()->route('user.enduser.login');
		}		
    }
    
    
    public function logout() {
		Auth::logout();		
		return redirect()->route('user.enduser.login');
	}
	
	
}