<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Traits\MediaUploadingTrait;
use App\Http\Requests\MassDestroyProductRequest;
use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductTag;
use Gate;
use Illuminate\Http\Request;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Symfony\Component\HttpFoundation\Response;

class ProductShowController extends Controller
{
    use MediaUploadingTrait;

    public function index()
    {
        

        $products = Product::with(['categories', 'tags', 'media'])->get();

        return view('user.products.index', compact('products'));
    }

    public function create()
    {
        
    }

    public function store(StoreProductRequest $request)
    {
    }

    public function edit(Product $product)
    {
        
    }

    public function update(UpdateProductRequest $request, Product $product)
    {
        
}
    public function show(Product $product, $id)
    {
        
        //$product->load('categories', 'tags');
        $product=Product::find($id)->load('categories', 'tags');

        return view('user.products.show', compact('product'));
    }

    public function destroy(Product $product)
    {
        
    }

    public function massDestroy(MassDestroyProductRequest $request)
    {
        
    }

    
}
